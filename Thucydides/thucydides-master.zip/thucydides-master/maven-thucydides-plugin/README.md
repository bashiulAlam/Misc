## Thucydides Maven Plugin
We need to build this plugin separately, as it depends on the core Thucydides libraries being present in the local Maven repo.