import static ch.qos.logback.classic.Level.WARN

root(WARN, ["CONSOLE"])

logger("org.hibernate", WARN, ["CONSOLE"])