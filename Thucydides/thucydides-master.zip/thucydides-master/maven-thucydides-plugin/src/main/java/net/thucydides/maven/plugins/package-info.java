/**
 * The implementation of the Thucydides Maven plugin.
 */
package net.thucydides.maven.plugins;