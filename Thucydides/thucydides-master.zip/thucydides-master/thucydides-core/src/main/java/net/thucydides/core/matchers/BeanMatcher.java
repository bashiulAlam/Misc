package net.thucydides.core.matchers;

public interface BeanMatcher {
    boolean matches(Object target);
}
