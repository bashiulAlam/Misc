package net.thucydides.core.pages.injectors;

import java.util.List;

public interface FieldInjectorService {
    List<PageFieldInjector> getFieldInjectors();
}
