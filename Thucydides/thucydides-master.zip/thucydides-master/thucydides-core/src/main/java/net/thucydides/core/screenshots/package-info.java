/**
 * This package is in charge of recording and storing screenshots taken during the test run.
 */
package net.thucydides.core.screenshots;