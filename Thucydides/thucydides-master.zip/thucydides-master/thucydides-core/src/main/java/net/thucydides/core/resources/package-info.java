/**
 * Classpath resource utilities.
 */
package net.thucydides.core.resources;