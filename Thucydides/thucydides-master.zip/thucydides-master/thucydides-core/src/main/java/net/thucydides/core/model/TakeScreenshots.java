package net.thucydides.core.model;

public enum TakeScreenshots {
    FOR_EACH_ACTION,
    BEFORE_AND_AFTER_EACH_STEP,
    AFTER_EACH_STEP,
    FOR_FAILURES
}
