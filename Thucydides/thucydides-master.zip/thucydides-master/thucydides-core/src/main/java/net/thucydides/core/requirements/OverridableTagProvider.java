package net.thucydides.core.requirements;

/**
 * A default tag provider that can be overridden by any additional tag provider if present on the classpath.
 */
public interface OverridableTagProvider extends CoreTagProvider {}
