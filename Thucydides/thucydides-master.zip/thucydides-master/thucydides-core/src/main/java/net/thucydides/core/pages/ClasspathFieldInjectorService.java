package net.thucydides.core.pages;

/**
 * A description goes here.
 * User: john
 * Date: 1/03/13
 * Time: 9:56 AM
 */
public class ClasspathFieldInjectorService {
}
