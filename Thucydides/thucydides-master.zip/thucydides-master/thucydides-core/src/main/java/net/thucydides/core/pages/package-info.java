/**
 * Classes designed to make it easier to work with Page Objects in WebDriver.
 */
package net.thucydides.core.pages;