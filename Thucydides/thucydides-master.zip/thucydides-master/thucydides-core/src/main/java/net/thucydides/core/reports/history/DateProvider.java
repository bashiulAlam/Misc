package net.thucydides.core.reports.history;

import org.joda.time.DateTime;

public interface DateProvider {

    DateTime getCurrentTime();
}
