package net.thucydides.core.requirements;

/**
 * A core system-provided tag provider: used to know if any additional providers are present on the classpath.
 */
public interface CoreTagProvider {}
