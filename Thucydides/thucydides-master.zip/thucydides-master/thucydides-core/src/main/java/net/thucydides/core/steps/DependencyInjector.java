package net.thucydides.core.steps;

public interface DependencyInjector {
    void injectDependenciesInto(Object object);
}
