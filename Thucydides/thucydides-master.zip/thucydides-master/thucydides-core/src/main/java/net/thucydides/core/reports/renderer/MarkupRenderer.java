package net.thucydides.core.reports.renderer;

public interface MarkupRenderer {
    String render(String text);
}
