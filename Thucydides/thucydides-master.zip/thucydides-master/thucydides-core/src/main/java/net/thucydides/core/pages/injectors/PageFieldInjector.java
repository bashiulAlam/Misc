package net.thucydides.core.pages.injectors;

/**
 * Allows you to instantiate PageObject fields in
 */
public interface PageFieldInjector {
}
