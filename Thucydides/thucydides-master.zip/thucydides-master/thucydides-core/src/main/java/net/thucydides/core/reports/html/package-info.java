/**
 * XML Report generation.
 */
package net.thucydides.core.reports.html;