package net.thucydides.core.fixtureservices;

import java.util.List;

public interface FixtureProviderService {
    List<FixtureService> getFixtureServices();
}
