package net.thucydides.core.requirements;

import java.util.List;

public interface RequirementsProviderService {
    List<RequirementsTagProvider> getRequirementsProviders();
}
