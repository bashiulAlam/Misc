package net.thucydides.core.pages.injectors;

public class ThucydidesPageFragmentInjector implements PageFieldInjector {
}
