package net.thucydides.core.fixtureservices;

/**
 * A description goes here.
 * User: john
 * Date: 2/05/13
 * Time: 2:18 PM
 */
public class FixtureException extends RuntimeException {
    public FixtureException(String message, Throwable cause) {
        super(message, cause);
    }
}
