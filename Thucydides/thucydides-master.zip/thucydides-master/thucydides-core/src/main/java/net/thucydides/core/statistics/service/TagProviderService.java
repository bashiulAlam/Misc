package net.thucydides.core.statistics.service;

import java.util.List;

public interface TagProviderService {
    List<TagProvider> getTagProviders();
}
