package net.thucydides.core.statistics;

public interface TestCount {
    int getNextTest();
    int getCurrentTestNumber();
}
