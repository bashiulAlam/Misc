package net.thucydides.core.model;

/**
 * Created by john on 4/07/2014.
 */
public class TestFailureException extends Exception {
    public TestFailureException(String message) {
        super(message);
    }
}
