package net.thucydides.core.model;

public enum TestType {
    ANY, AUTOMATED, MANUAL
}
