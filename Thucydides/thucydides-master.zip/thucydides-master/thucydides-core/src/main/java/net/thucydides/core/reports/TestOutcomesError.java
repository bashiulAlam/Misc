package net.thucydides.core.reports;

/**
 * Created by john on 22/09/2014.
 */
public class TestOutcomesError extends Error {

    public TestOutcomesError(String message) {
        super(message);
    }
}
