/**
 * Thucydides generates reports in HTML and XML by default. 
 */
package net.thucydides.core.reports;