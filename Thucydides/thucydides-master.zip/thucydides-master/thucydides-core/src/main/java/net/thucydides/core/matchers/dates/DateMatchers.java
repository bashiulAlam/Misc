package net.thucydides.core.matchers.dates;

import org.hamcrest.Factory;
import org.hamcrest.Matcher;
import org.joda.time.DateTime;
import org.joda.time.Period;

import java.util.Collection;
import java.util.Date;

/**
 * Hamcrest matchers to be used with Dates.
 */
public class DateMatchers {

    @Factory
    public static Matcher<Date> isSameAs(Date expectedDate){
        return new DateIsSameAsMatcher(expectedDate);
    }

    @Factory
    public static Matcher<Date> isCloseTo(Date expected, Period within){
        return new TimeIsCloseToAsMatcher(expected, within);
    }

    @Factory
    public static Matcher<DateTime> isCloseTo(DateTime expected, Period within){
        return new DateTimeIsCloseToAsMatcher(expected, within);
    }

    @Factory
    public static Matcher<Date> isBefore(Date expectedDate){
        return new DateIsBeforeMatcher(expectedDate);
    }

    @Factory
    public static Matcher<Date> isAfter(Date expectedDate){
        return new DateIsAfterMatcher(expectedDate);
    }

    @Factory
    public static Matcher<Date> isBetween(Date startDate, Date endDate){
        return new DateIsBetweenMatcher(startDate, endDate);
    }

    @Factory
    public static Matcher<DateTime> isSameAs(DateTime expectedDate){
        return new DateTimeIsSameAsMatcher(expectedDate);
    }

    @Factory
    public static Matcher<DateTime> isBefore(DateTime expectedDate){
        return new DateTimeIsBeforeMatcher(expectedDate);
    }

    @Factory
    public static Matcher<DateTime> isAfter(DateTime expectedDate){
        return new DateTimeIsAfterMatcher(expectedDate);
    }

    @Factory
    public static Matcher<DateTime> isBetween(DateTime startDate, DateTime endDate){
        return new DateTimeIsBetweenMatcher(startDate, endDate);
    }
    
    @Factory
    public static Matcher<Collection<DateTime>> containsSameDateTimesAs(Collection<DateTime> expectedDates) {
        return new DateTimeCollectionContainsSameDatesMatcher(expectedDates);
    }

    @Factory
    public static Matcher<Collection<Date>> containsSameDatesAs(Collection<Date> expectedDates) {
        return new DateCollectionContainsSameDatesMatcher(expectedDates);
    }
}
