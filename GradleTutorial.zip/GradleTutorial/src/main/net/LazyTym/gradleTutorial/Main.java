import java.util.Arrays;
import org.apache.commons.lang3.StringUtils;

public class Main{
	public static void main(String[] args) {
		System.out.println("this");
		System.out.println(StringUtils.swapCase(Arrays.toString(args)));
	}
}

